﻿namespace A42.Planning.Data.Dtos
{
    public class TeamDto
    {
        public int Id { get; set; }
        public string Name { get; set; }
    }
}
