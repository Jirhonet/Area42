﻿namespace A42.Planning.Data.Dtos
{
    public class EmployeeDto
    {
        public int Id { get; set; }
        public int? TeamId { get; set; }
        public string FullName { get; set; }
    }
}
