﻿namespace A42.Planning.Domain.Abstractions
{
    public interface IEmployee
    {
        int Id { get; }
        string FullName { get; }
    }
}
